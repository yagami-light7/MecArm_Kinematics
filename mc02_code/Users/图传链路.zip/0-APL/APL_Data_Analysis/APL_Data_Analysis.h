#pragma once

#include "main.h"
#include "HDL_VT.h"

#define JOINTS_NUM  6

typedef struct
{
    uint8_t data[30];

    // 解析完毕 机械臂关节角度
    float custom_angle_set[JOINTS_NUM];
}custom_control_t;

typedef struct
{
    uint8_t data[12];

    // 解析完毕 键鼠数据
    int16_t mouse_x;
    int16_t mouse_y;
    int16_t mouse_z;
    int8_t left_button_down;
    int8_t right_button_down;
    uint16_t keyboard_value;
    uint16_t reserved;

    int8_t last_left_button_down;
    int8_t last_right_button_down;
    uint16_t last_keyboard_value;

}remote_control_t;

typedef struct
{
    uint8_t data[21];

    // 解析完毕 键鼠+摇杆数据
    uint8_t sof_1; //0xA9
    uint8_t sof_2; //0X53

    uint64_t ch_0;
    uint64_t ch_1;
    uint64_t ch_2;
    uint64_t ch_3;
    uint64_t mode_sw;
    uint64_t pause;
    uint64_t fn_1;
    uint64_t fn_2;
    uint64_t wheel;
    uint64_t trigger;

    int16_t mouse_x;
    int16_t mouse_y;
    int16_t mouse_z;
    uint8_t mouse_left;
    uint8_t mouse_right;
    uint8_t mouse_middle;
    uint16_t key;
    uint16_t crc16;

}vt_rc_control_t;

#ifdef __cplusplus
class Class_Data_Analysis
{
public:
    /* Functions */
    void Init(Class_Video_Transmission *_VT_Module_Obj_, UART_Manage_Object_t *_UART_Manage_Obj_);
    void data_analysis(void);

    /* Class */
    Class_Video_Transmission *VT_Moudle;

    /* Struct */
    custom_control_t custom_control;
    remote_control_t remote_control;
    vt_rc_control_t  vt_rc_control;

private:

};

/**
 * @brief 构造数据解析对象
 */
extern Class_Data_Analysis Data_Analysis;

#endif


#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief          数据解析任务
 * @param[in]      none
 * @retval         none
 */
extern void Data_Analysis_Task(void *pvParameters);


#ifdef __cplusplus
}

#endif