#pragma once

#include "main.h"


#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief          将uint8_t数组转化为float数组
 *
 * @param[in]      uint8_data   需要转化的uint8_t数组
 *                 float_data   转化后的float数组
 *                 num_floats   float数组元素个数
 *
 * @retval         none
 */
extern void uint8_to_float(uint8_t *uint8_data, float *float_data, int num_floats);


#ifdef __cplusplus
}
#endif